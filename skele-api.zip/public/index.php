<?php
	/**
	* SkeleAPI - Public Index
	*
	* Public index page
	* CHANGES: No changes required.
	*
	* @category SkeleAPI
	* @package /public/index.php
	* @see /api/load.php For all app tags
	* 
	*/

	require __DIR__ . '/../api/load.php';
?>